package edu.cooper.ee.ece366.symstagram;

import edu.cooper.ee.ece366.symstagram.model.User;
import edu.cooper.ee.ece366.symstagram.Service;
import spark.Request;
import spark.Response;

import java.util.HashMap;
import java.util.Optional;

public class Handler {
    HashMap<String, User> userSet = new HashMap<String, User>();

    public Handler(){}
    Service service = new Service();

    public static void UpdateResponse(Response response, Integer code, String message) {
        response.status(code);
        response.body(message);
        System.out.println(message);
    }

    public User Register(Request request, Response response) {
        User user = service.createUser(
                request.queryParams("name"),
                request.queryParams("password"),
                request.queryParams("phone"),
                request.queryParams("email"));
        userSet.put(user.getEmail(), user);

        UpdateResponse(response,200,String.valueOf(user));

        return user;
    }

}
