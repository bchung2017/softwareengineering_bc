package edu.cooper.ee.ece366.symstagram.model;

import com.google.gson.annotations.Expose;

public class Post {
    @Expose private String postText;

    public Post(String postText) {
        this.postText = postText;
    }

    public String getPostText() {
        return postText;
    }

    public void setPostText(String postText) {
        this.postText = postText;
    }
}


