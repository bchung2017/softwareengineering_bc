package edu.cooper.ee.ece366.symstagram;

import com.google.gson.Gson;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import edu.cooper.ee.ece366.symstagram.util.JsonTransformer;
import spark.Spark;

public class Main {
    public static void main(String[] args) throws SQLException {
        Gson gson = new Gson();
        String url = "jdbc:h2:~/testdb2";
        Connection connection = DriverManager.getConnection(url);
        Service service = new Service();
        Handler handler = new Handler();

        JsonTransformer jsonTransformer = new JsonTransformer();

        Spark.get("/ping", (req, res) -> "OK");
        Spark.post("/user", (request, response) -> handler.Register(request, response), jsonTransformer);
    }
}
